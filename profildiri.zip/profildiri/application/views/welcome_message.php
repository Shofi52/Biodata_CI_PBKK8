<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shofiyah M</title>
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style type = "text/css">
        #header{
            background-color: #362F19;
            color: #dbc478;
            text-align: center;
        }
        a:link{color: #dbc478;}
        a:visited{color: #dbc478;}
        a:hover{color: #6d6038;}
        a:active{color: #dbc478;}
        .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 60%;
        }

    </style>
</head> 
<body style="background-color: #dbc478;">
    <div id="header">
        <h1>My profile</h1>
        <h4>Let's get to know me ^_^</h4>
        <br>
    </div>
        <div class="container">
            <br>
            <div class="row">
                <div class="col" style="font-size: large;"> <br><br>
                    <b>About Me</b><br>
                    <B>Name:</B> Shofiyah Mardhiyah <br>
                    <B>Date of Birth:</B> 28th December 1999 <br>
                    <B>Place of Birth:</B> Sidoarjo <br>
                    <B>Hobby:</B> Reading <br><br>
                    <b>My life</b><br>
                    I was born on the 28th of December 1999 at Siti Khadijah Hospital, Sidoarjo as the second child.
                    I started elementary school at Insan Kamil Islamic School and moved to Malaysia during 4th grade.
                    I stayed at Malaysia for seven and a half years before coming back to Indonesia on my second year of high school.
                    <br><br><br>
            
                </div>
                <div class="col" style="font-size: large;">
                    <img src="myprofile.PNG" alt="My photo" width="330" height="460" class="center">
                </div>
            </div>
        </div>
</body>
</html>